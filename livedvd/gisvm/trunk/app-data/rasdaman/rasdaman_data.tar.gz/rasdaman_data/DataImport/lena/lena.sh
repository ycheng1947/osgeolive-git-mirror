#!/bin/sh
 
 wcps_db=petascopedb
 wcps_host=localhost 
wcps_port=8998
wcps_user=petauser 
rasql -q 'create collection lena GreySet' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE 
rasql -q '   insert into lena values inv_tiff($1)' --file lena.tiff --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE

