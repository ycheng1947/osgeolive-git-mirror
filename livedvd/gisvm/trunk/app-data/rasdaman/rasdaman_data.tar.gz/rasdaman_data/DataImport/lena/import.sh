#!/bin/sh

wd=$(dirname $0)
tmp=$wd/import_script.sh
echo "#!/bin/sh" > $tmp
echo " wcps_db=petascopedb" >> $tmp
echo " wcps_host=localhost " >> $tmp
echo "wcps_port=8998" >> $tmp
echo "wcps_user=petauser " >> $tmp


for i in $( ls $wd/../data)
 do
 no_files=$(($(ls $wd/../data/$i  | wc -l) - 1))
echo $no_files
 echo "rasql -q 'create collection $i GreySet3' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE " >> $tmp
 echo "rasql -q '   insert into $i values marray x in [0:$no_files,0:885,0:710] values 99c tiling regular [0:0,0:885,0:710] index rc_index' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE" >> $tmp
k=0
	for j in $( ls $wd/../data/$i)
do
	echo "rasql -q 'update $i as c set c[$k,0:885,0:710] assign  inv_tiff(\$1)' --file $wd/../data/$i/$j  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE" >> $tmp
k=$(($k+1))
done
 echo " psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"insert into PS_Coverage ( name, nulldefault, interpolationtypedefault, nullresistancedefault) values ( '$i', '0', 5, 2)\" " >> $tmp

echo "  x_id=\$(psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"select id from PS_Coverage where name = '$i' \" | head -3 | tail -1)  " >>$tmp

echo " echo \$x_id" >>$tmp
  echo " psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"insert into PS_CellDomain ( coverage, i, lo, hi )  values ( \$x_id, 0, 0, 5)\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"insert into PS_CellDomain (coverage, i, lo, hi )  values ( \$x_id, 1, 0, 885)\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c  \"insert into PS_CellDomain (coverage, i, lo, hi )  values ( \$x_id, 2, 0, 710)\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c  \"insert into PS_Domain ( coverage, i, name, type, numLo, numHi) values ( \$x_id, 2, 'x', 1, 0, 1 )\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"insert into PS_Domain ( coverage, i, name, type, numLo, numHi) values ( \$x_id, 1, 'y', 2, 0, 1 )\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c  \"insert into PS_Domain ( coverage, i, name, type, numLo, numHi, strLo, strHi) values ( \$x_id, 0, 't', 6, '0', '5', '1950', '2010' )\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c  \"insert into PS_Range (coverage, i, name, type) values (\$x_id, 0, 'pan', 7)\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"insert into PS_InterpolationSet (coverage, interpolationType, nullResistance) values ( \$x_id, 5, 2)\"" >>$tmp 
  echo " psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c   \"insert into PS_NullSet ( coverage, nullValue) values ( \$x_id, '0')\"" >>$tmp 
echo " psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c   \"insert into PS_crsdetails ( coverage, low1, high1, low2, high2) values ( \$x_id, 111.975, 156.275, -44.525, -8.975)\" " >>$tmp

echo " y1_id=\$(psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"select id from PS_domain where coverage = \$x_id and type= 1 \" | head -3 | tail -1)  " >>$tmp
echo "y2_id=\$(psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"select id from PS_domain where coverage = \$x_id and type= 2 \" | head -3 | tail -1)  " >>$tmp
echo "y5_id=\$(psql -d \$wcps_db --port \$wcps_port -U \$wcps_user -c  \"select id from PS_domain where coverage = \$x_id and type= 6 \" | head -3 | tail -1)  " >>$tmp
echo "psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c   \"insert into PS_crsset ( axis, crs) values ( \$y1_id, 8)\" " >>$tmp
echo "psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c   \"insert into PS_crsset ( axis, crs) values ( \$y2_id, 8)\" " >>$tmp
echo "psql -d \$wcps_db --port \$wcps_port  -U \$wcps_user -c   \"insert into PS_crsset ( axis, crs) values ( \$y5_id, 8)\" " >>$tmp
chmod 775 $tmp
echo "done"
done
