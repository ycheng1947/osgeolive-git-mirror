#!/bin/bash

for i in `seq 1 11` ; do
    read
    echo $REPLY >NN3_$i.dat
done