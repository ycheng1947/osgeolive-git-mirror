#!/bin/sh
   rasql=rasql
 wcps_db=petascopedb
 wcps_host=localhost 
wcps_port=8998
wcps_user=petauser 
$rasql -q 'create collection decadal_avg_mean_summer_airtemp GreySet3' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE 
$rasql -q '   insert into decadal_avg_mean_summer_airtemp values marray x in [0:5,0:885,0:710] values 99c' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
$rasql -q 'update decadal_avg_mean_summer_airtemp as c set c[0,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_summer_airtemp/mnan5160sum.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
$rasql -q 'update decadal_avg_mean_summer_airtemp as c set c[1,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_summer_airtemp/mnan6170sum.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
$rasql -q 'update decadal_avg_mean_summer_airtemp as c set c[2,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_summer_airtemp/mnan7180sum.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
$rasql -q 'update decadal_avg_mean_summer_airtemp as c set c[3,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_summer_airtemp/mnan8190sum.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
$rasql -q 'update decadal_avg_mean_summer_airtemp as c set c[4,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_summer_airtemp/mnan9100sum.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
$rasql -q 'update decadal_avg_mean_summer_airtemp as c set c[5,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_summer_airtemp/mnanz0107sum.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
 
rasql -q 'create collection decadal_avg_mean_winter_airtemp GreySet3' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE 
rasql -q '   insert into decadal_avg_mean_winter_airtemp values marray x in [0:5,0:885,0:710] values 99c' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update decadal_avg_mean_winter_airtemp as c set c[0,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_winter_airtemp/mnan5160win.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update decadal_avg_mean_winter_airtemp as c set c[1,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_winter_airtemp/mnan6170win.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update decadal_avg_mean_winter_airtemp as c set c[2,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_winter_airtemp/mnan7180win.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update decadal_avg_mean_winter_airtemp as c set c[3,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_winter_airtemp/mnan8190win.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update decadal_avg_mean_winter_airtemp as c set c[4,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_winter_airtemp/mnan9100win.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update decadal_avg_mean_winter_airtemp as c set c[5,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/decadal_avg_mean_winter_airtemp/mnanz0107win.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
 
 
rasql -q 'create collection gridded_avg_1961_1990_mean_summer_airtemp GreySet3' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE 
rasql -q '   insert into gridded_avg_1961_1990_mean_summer_airtemp values marray x in [0:0,0:885,0:710] values 99c' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update gridded_avg_1961_1990_mean_summer_airtemp as c set c[0,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/gridded_avg_1961_1990_mean_summer_airtemp/mnsum6190.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
 
rasql -q 'create collection gridded_avg_1961_1990_mean_winter_airtemp GreySet3' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE 
rasql -q '   insert into gridded_avg_1961_1990_mean_winter_airtemp values marray x in [0:0,0:885,0:710] values 99c' --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE
rasql -q 'update gridded_avg_1961_1990_mean_winter_airtemp as c set c[0,0:885,0:710] assign  inv_tiff($1)' --file /mnt/rasservice/DataImport/ccip_all/scripts/../data/gridded_avg_1961_1990_mean_winter_airtemp/mnwin6190.tif  --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE

