#!/bin/sh

wcps_db=petascopedb
wcps_host=localhost
wcps_port=8998
wcps_user=petauser
wcps_passwd=rasdaman

wd=$(dirname $0)
echo $wd
for i in $( ls $wd/../data)
 do
  echo rasql -q \'drop collection $i\' 
  rasql --query "drop collection $i " --user rasadmin --passwd rasadmin --port 9001 -d RASSERVICE 
  psql -d $wcps_db  --port $wcps_port  -U $wcps_user -c  "delete from PS_Coverage where name = '$i' "
  echo psql -d $wcps_db --port $wcps_port -h $wcps_host -U $wcps_user -c  "delete from PS_Coverage where name = '$i' "
done
