<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Subsetting: <br>how to cut out parts from a coverage</h1>

<p>
Frequently one does not want to download the whole coverage, but only part of it. Such a subset always is a coverage again, and actually keeps all other characteristics unchanged, beyond its reduced extent.
<p>
Actually there are two different variants of subsetting:
<ul>
  <li><a href="23_subsetting_domain_trim.php">trimming</a> a coverage extracts a cutout along the axis indicated, specified by a lower and upper bound on this axis. Obviously, as we talk about <i>sub</i>setting, the new interval limits must lie inside the original coverage's domain.
  <li><a href="24_subsetting_domain_slice.php">slicing</a> a coverage extracts a slice (mathematicians would call this a <i>hyperplane</i>) from a given coverage along one of its axes, thereby reducing dimension by one. Again, the slicing point must lie within the original coverage's domain.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/subsetExpr.php">subsetExpr</a>

<?php mkNavigation("subsetting:","20_subsetting.php","trimming","23_subsetting_domain_trim.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
