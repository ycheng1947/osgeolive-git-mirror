<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Range subsetting: <br>how to extract cell components</h1>
<p>
Often coverages have a complex cell structure. Following WCS, cells can have atomic cell types with only one <i>field</i> (ex: greyscale images) or complex fields (ex: 3-component RGB images, 242-band EO-1 scenes). In the conceptual coverage model of WCS, these components are identified by their names. Using these names WCPS allows to extract components (and actually also to recompose them).
<p>
<b>Example:</b> The following three requests extract the red, green, and blue channel of coverage <code>rgb</code>, resp.; the dot notation follows programming language notation:

<pre class="code">for m in ( mowglie )
return
        encode( <span class="hilite">m.red</span>, "jpeg" )
</pre>
<pre class="code">for m in ( mowglie )
return
        encode( <span class="hilite">m.green</span>, "jpeg" )
</pre>
<pre class="code">for m in ( mowglie )
return
        encode( <span class="hilite">m.blue</span>, "jpeg" )
</pre>
<p>
Below the respective results can be seen:
<div class="response">
<nobr>
  <img align="center" src="images/25_rgb-red.jpg" width="200">
  &nbsp;
  <img align="center" src="images/25_rgb-green.jpg" width="200">
  &nbsp;
  <img align="center" src="images/25_rgb-blue.jpg" width="200">
</nobr>
</div>

<p>
<b>Background information:</b>
<ul>
  <li>Actually, range subsetting is a special case of <a href="30_induced.php">induced operations</a>.
  <li>The WCS extension for complex range field components currently is not supported by WCPS.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/fieldExpr.php">fieldExpr</a>

<?php mkNavigation("slicing","24_subsetting_domain_slice.php","induced operations","30_induced.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
