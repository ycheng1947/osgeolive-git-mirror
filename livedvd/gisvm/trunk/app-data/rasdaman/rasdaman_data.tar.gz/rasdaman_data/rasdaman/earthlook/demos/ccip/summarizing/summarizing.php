<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">                                                                  

<head>
  <?php $homePath="../../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
  <script language="javascript">
  var WCPS_REQUEST = "<pre class='code'>for c in ( lena )\nreturn\n  encode(\n    coverage histogram over $n x(0:255)\n    values count( c = $n ),\n    &quot;csv&quot; )</pre>";
  </script>
</head>

<body>
<script type="text/javascript" src="../scripts/wz_tooltip.js"></script>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

    <h1>Summarizing Coverage Data</h1>

    <p>
    <b>Use Case:</b>
    Scientist wants to determine a histogram over an 8-bit image.
    </p>
    <p>
    <b>The Service:</b>
    A <a href=""><span onMouseOver="Tip(WCPS_REQUEST)">prefabricated WCPS request</span></a>, launched by a mouse click, delivers the histogram as a CSV (comma-separated values) list which can be graphed easily.
    </p>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
  <td valign="top" width="300">
    <img src="lena.png" border="0" width="300">
    <br>
    (original 512 x 512 pixels)
  </td>
  <td valign="top">
    <iframe src="<?php echo $GWT_VIEW . "/summarizing.html";?>" name="demo" width="100%" height="330px" hspace="0" vspace="0" marginwidth="0" marginheight="0" frameborder="no">
      Sorry, your browser doesn't support <i>iframe</i>s - cannot display results!
    </iframe>
  </td>
</tr>
</table>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>

