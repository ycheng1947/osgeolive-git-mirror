<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Condensers shorthand</h1>

<p>
Similar to what SQL aggregates do on sets, the condenser shorthands allow to obtain summary information about coverages.
<p>
<b>Example:</b> "the average of the red components of all cells in the image".
<pre class="code">for c in ( rgb )
return
	<span class="hilite">avg( c.red )</span>
</pre>
<p>
The following table lists the shorthands available;
<code>a</code> is assumed to be a numeric, <code>b</code> a Boolean coverage expression.

<table class="text" border="0" cellspacing="0" cellpadding="0">
<tr>
  <th class="text">condenser</th>
  <th class="text">meaning</th>
</tr>
<tr>
  <td class="text"><code>add(a)</code></td>
  <td class="text">sum over all cells in a</td>
</tr>
<tr>
  <td class="text"><code>avg(a)</code></td>
  <td class="text">average of all cells in a</td>
</tr>
<tr>
  <td class="text"><code>min(a)</code></td>
  <td class="text">minimum of all cells in a</td>
</tr>
<tr>
  <td class="text"><code>max(a)</code></td>
  <td class="text">maximum of all cells in a</td>
</tr>
<tr>
  <td class="text"><code>count(b)</code></td>
  <td class="text">number of cells in b containing true / non-zero values</td>
</tr>
<tr>
  <td class="text"><code>some(b)</code></td>
  <td class="text">is there any cell in b with value true?</td>
</tr>
<tr>
  <td class="text"><code>all(b)</code></td>
  <td class="text">do all cells of b have value true?</td>
</tr>
</table>

<p>
<b>Example:</b> "the number of vegetation pixels in <code>satScene</code>."
<pre class="code">for s in ( satScene )
return
        <span class="hilite">count( (s.0-s.1)/(s.0+s.1) &gt; 0.6 )</span>
</pre>
<p>
The response is a single integer number, so no <code>encode()</code> is needed.

<p>
<b>See manual:</b>
<a href="../wcps-manual/reduceExpr.php">reduceExpr</a>

<?php mkNavigation("condensers","60_condense.php","general condenser","66_condense-full.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
