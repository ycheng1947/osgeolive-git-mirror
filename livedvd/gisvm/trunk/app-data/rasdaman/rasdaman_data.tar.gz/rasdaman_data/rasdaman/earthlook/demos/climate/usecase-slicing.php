<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php static $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>

  <script language="javascript">
  var REQUEST_3D_T = '<pre class="code">for m in (mowglie)\n'
                     + 'return\n'
                     + '    encode( m[ t(10) ], "png" )</pre>';
  var REQUEST_3D_X = '<pre class="code">for m in (mowglie)\n'
                     + 'return\n'
                     + '    encode( m[ x(10) ], "png" )</pre>';
  var REQUEST_3D_Y = '<pre class="code">for m in (mowglie)\n'
                     + 'return\n'
                     + '    encode( m[ y(10) ], "png" )</pre>';


  </script>
</head>

<body>
<script type="text/javascript" src="wz_tooltip.js"></script>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>2-D Image Slicing</h1>

<p>

<br>
Click on cubes to request image slice from server; while the mouse is over the cube, the corresponding WCPS request will be displayed.
</p>

<ul>
  <li>All possible 2-D slices from x/y/t a 3-D image named <code>mowglie</code>:
  <table border="0">
  <tr>

    <td align="center">
      <a href="javascript:document.climate_t.submit()" onMouseOver="Tip(REQUEST_3D_T)"><img src="cube-t.png" border="none" width="140" height="110"></a>
    </td>
    <form name="climate_t" action="<?php echo $SERVICE_WCPS; ?>" method="post" target="climate-temp">
      <input type="hidden" name="query" value='for m in (mowglie) return encode(  (m[ y(10) ]), "png" )'>
    </form>

    <td align="center">
      <a href="javascript:document.climate_x.submit()" onMouseOver="Tip(REQUEST_3D_X)"><img src="cube-x.png" border="none" width="140" height="110"></a>
    </td>
    <form name="climate_x" action="<?php echo $SERVICE_WCPS; ?>" method="post" target="climate-temp">
      <input type="hidden" name="query" value='for m in (mowglie) return encode(  (m[ t(10) ]), "png" )'>
    </form>

    <td align="center">
      <a href="javascript:document.climate_y.submit()" onMouseOver="Tip(REQUEST_3D_Y)"><img src="cube-y.png" border="none" width="140" height="110"></a>
    </td>
    <form name="climate_y" action="<?php echo $SERVICE_WCPS; ?>" method="post" target="climate-temp">
      <input type="hidden" name="query" value='for m in (mowglie) return encode( (m[ x(10) ] ), "png" )'>
    </form>

  </tr>
  <tr>
    <td colspan="3">
      <iframe name="climate-temp" src="climate-init-slicing.html" width="200" height="101" marginwidth="0" marginheight="0" vspace="0" hspace="0">
        Your browser does not support iframes, hence the service unfortunately cannot be invoked.
      </iframe>
    </td>
  </tr>
  </table>
  <p>

</ul>

<p>
As can be seen, WCPS allows to extract lower-dimensional subsets of any dimension using just one simple mechanism.
</p>


<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
