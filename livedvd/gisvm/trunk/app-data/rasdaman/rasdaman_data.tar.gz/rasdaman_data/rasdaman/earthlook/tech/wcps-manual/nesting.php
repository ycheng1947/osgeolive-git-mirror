<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>Nesting</h1>

<p>
All operators, constructors, and functions can be nested arbitrarily, provided that each sub-expression's result type matches the required type at the position where the sub-expression occurs. This holds without limitation for all arithmetic, Boolean, String, and coverage-valued expressions.

<p>
<span class="note">NOTE</span> An <span class="syntax">encodeExpr</span> cannot appear inside an expression, it is always the outermost expression.
</p>

<h2>Example</h2>
<p>
The following example first adds 1 to each cell of coverage C and then multiplies each cell by 2:
<pre class="code">
( C + 1 ) * 2
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
