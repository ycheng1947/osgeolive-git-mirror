<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath=".."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>Video Download</h1>
<ul>
  <li>NASA is experimenting with the <a href="http://www.opengeospatial.org" target="ogc">OGC</a> <a href="http://www.opengeospatial.org/standards/wcps" target="ogc">WCPS</a> standard as a means to achieve interoperability in their ground / space communication. <a href="http://earthlook.org/videos/nasa-wcps-for-space-ground-interoperability.mp4" target="video">This video</a> documents first results.
  <p> </p>
  <li>To document the results of our 
  <a href="http://www.opengeospatial.org" target="ogc">OGC</a>
  <a href="http://www.opengeospatial.org/pub/www/ows5/demo.html">OWS-5</a> project activities, this video has been prepared:
  <ul>
    <li>short version [ <a href="http://kahlua.eecs.jacobs-university.de/~earthlook/videos/ows5-wcps_shortShort.mpg" target="video">MPEG</a> (5 MB) | <a href="http://kahlua.eecs.jacobs-university.de/~earthlook/videos/ows5-wcps_shortShort.avi" target="video">AVI</a> (7.5 MB) ]
    <br>codec info: video <code>mpeg12</code>, audio <code>mp3</code>
    <li>long version  [ <a href="http://kahlua.eecs.jacobs-university.de/~earthlook/videos/ows5-wcps_long.mpg" target="video">MPEG</a> (11 MB)      | <a href="http://kahlua.eecs.jacobs-university.de/~earthlook/videos/ows5-wcps_long.avi" target="video">AVI</a> (18 MB) ]
    <br>codec info: video <code>ffcamtasia</code>, audio <code>pcm</code>
  </ul>
</ul>

<p>
<b>Viewing problems?</b>
In order to view them properly you need to have the appropriate codec (mpeg2) installed.
Try downloading and installing this <a href="http://www.free-codecs.com/download/Codec_Pack_All_In_1.htm" target="free-codecs">free codec pack</a>.
Upon installing, "MPEG2 Filter" must be chosen.
</p>

<p>
<b>Disclaimer:</b> opinions expressed in these videos do not necessarily reflect positions of OGC.
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
