<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>generalCondenseExpr</h1>

<p>
The general <span class="syntax">generalCondenseExpr</span> consolidates cell values of a coverage along selected axes to a scalar value based on the condensing operation indicated. It iterates over a given domain while combining the result values of the <a href="scalarExpr.php" class="syntax">scalarExpr</a>s through the <b>condenseOpType</b> indicated.
</p>

<p>
Any summarisation function s() is admissible for a <span class="syntax">generalCondenseExpr</span> over some coverage if it has the following properties:
<ul>
<li>s() is a binary function between values of the coverage range type;</li>
<li>s() is commutative and associative.</li>
</ul>
</p>

<h2>Example</h2>
<p>Binary "+" on floating point numbers is admissible for a condenser on a float coverage, while binary "-" is not.</p>



<p>Let</p>
<div class="indent"><p>

<a name="op"></a><span class="syntax">op</span> be a <b>condenseOpType</b>, <br/>

<a name="d"></a><span class="syntax">d</span> be some <b>integer</b> with <span class="syntax">d</span> &gt; 0, <br/>

<a name="namei"></a><span class="syntax">name<sub>i</sub></span> be pairwise distinct <b>identifier</b>s which additionally, in the request on hand, are not used already as a variable in this expression's scope, <br/>

<a name="loi"></a><span class="syntax">lo<sub>i</sub></span> and <a name="hii"></a><span class="syntax">hi<sub>i</sub></span> be integers for 1 &#8804; i &#8804; <span class="syntax">d</span> with <span class="syntax">lo<sub>i</sub></span> &#8804; <span class="syntax">hi<sub>i</sub></span>, <br/>

<a name="P"></a><span class="syntax">P</span> be a <a href="booleanExpr.php" class="syntax">booleanExpr<a> possibly containing occurrences of <span class="syntax">name<sub>i</sub></span>, <br/>

<a name="V"></a><span class="syntax">V</span> be a <a href="scalarExpr.php" class="syntax">scalarExpr<a> possibly containing occurrences of <span class="syntax">name<sub>i</sub></span> <br/>
where <br/>
<div class="indent"><p>1 &#8804; i &#8804; <span class="syntax">d</span>.</p></div>


<p>Then,</p>

<div class="indent"><p>
For any <a href="scalarExpr.php" class="syntax">scalarExpr</a> <span class="syntax">S</span> <br/>
where </p>
<pre class="code">S  =  condense <a href="#op" class="syntax">op</a>
      over <a href="#namei" class="syntax">name<sub>1</sub></a> in (<a href="#loi" class="syntax">lo<sub>1</sub></a>,<a href="#hii" class="syntax">hi<sub>1</sub></a>),
           ... ,
           <a href="#namei" class="syntax">name</a><sub><a href="#d" class="syntax">d</a></sub> in (<a href="#loi" class="syntax">lo</a><sub><a href="#d" class="syntax">d</a></sub>,<a href="#hii" class="syntax">hi</a><sub><a href="#d" class="syntax">d</a></sub>)
      [ where <a href="#P" class="syntax">P</a> ]
      using <a href="#V" class="syntax">v</a></pre>
<p>  
<a name="S"></a><span class="syntax">S</span> is constructed as follows: </p>

<p>
<pre class="box">
Let <span class="syntax">S</span> = neutral element of type(<span class="syntax">V</span>); <br/>
for all <span class="syntax">name<sub>1</sub></span> &#8712; {<span class="syntax">lo<sub>1</sub></span>, ... ,<span class="syntax">hi<sub>1</sub></span>}</br>
    for all <span class="syntax">name<sub>2</sub></span> &#8712; {<span class="syntax">lo<sub>2</sub></span>, ... ,<span class="syntax">hi<sub>2</sub></span>}
        ...<br/>
          for all <span class="syntax">name<sub>d</sub></span> &#8712; {<span class="syntax">lo<sub>d</sub></span>, ... ,<span class="syntax">hi<sub>d</sub></span>} </br>
              let predicate <span class="syntax">P'</span> be obtained from expression <span class="syntax">P</span> 
              by substituting all occurrences of <span class="syntax">name<sub>i</sub></span> by <span class="syntax">V</span>
              where (<span class="syntax">name<sub>i</sub></span>,<span class="syntax">V</span>) &#8712; <span class="syntax">p</span>;
              if (<span class="syntax">P'</span>)
              then
                  let <span class="syntax">V'</span> be obtained from expression <span class="syntax">V</span> 
                  by substituting all occurrences of <span class="syntax">name<sub>i</sub></span> by <span class="syntax">V</span>
                  where (<span class="syntax">name<sub>i</sub></span>,<span class="syntax">V</span>) &#8712; p;
                  <span class="syntax">S</span> = <span class="syntax">S</span> <span class="syntax">op</span> value(<span class="syntax">V'</span>);
return <span class="syntax">S</span>
</pre>
</p>
</div>

<p>
Null values encountered <b>shall</b> be treated according to the : <br/>
-	if at least one non-null value is encountered in the repeated evaluation of <span class="syntax">V</span>, then all null values <b>shall</b> be ignored; <br/>
-	if <span class="syntax">V</span> is not evaluated at least once, or if there are only null-valued input values, then the overall result <b>shall</b> be null. <br/>
</p>

<h2>Example</h2>
<p>
For a filter kernel <span class="syntax">k</span>, the condenser must summarise not only over the cell under inspection, but also some neighbourhood. The following applies a filter kernel to some coverage <span class="syntax">C</span>; note that the result image is defined to have an <span class="syntax">x</span> and <span class="syntax">y</span> type axis.</p>
<pre class="code">
coverage filteredImage
over     px x(imageCrsDomain(C,x)),
         py y(imageCrsDomain(C,y))
values   condense +
         over    kx x(imageCrsDomain(k,x)),
                 ky y(imageCrsDomain(k,y))
         using   C[ (x(kx+px), y(ky+py) ] * k[ x(fx), y(fy) ]
</pre>
<p>
where <span class="syntax">k</span> is a 3x3 matrix like<br/>
</p>

<table border="1">
<tr>
<td>1</td>
<td>3</td>
<td>1</td>
</tr>
<tr>
<td>0</td>
<td>0</td>
<td>0</td>
</tr>
<tr>
<td>-1</td>
<td>-3</td>
<td>-1</td>
</tr>
</table>


<p>
<span class="note">NOTE</span> See <b>coverageConstExpr</b> for a way to specify the k matrix.
</p>

<p>
<span class="note">NOTE</span> Condensers are heavily used, among others, in these two situations:
<ul>
<li>To collapse Boolean-valued coverage expressions into scalar Boolean values so that they can be used in predicates.</li>
<li>In conjunction with the <a href="coverageConstructorExpr.php" class="syntax">coverageConstructorExpr</a> to phrase high-level imaging, signal processing and statistical operations.</li>
</ul>
</p>

<p>
<span class="note">NOTE</span> additional expressive power of <a href="condenseExpr.php" class="syntax">condenseExpr</a> over <a href="reduceExpr.php" class="syntax">reduceExpr</a> is twofold:
<ul>
<li>A WCPS implementation may offer further summarisation functions.</li>
<li>The <a href="condenseExpr.php" class="syntax">condenseExpr</a> gives explicit access to the coordinate values; this makes summarisation considerably more powerful (see example below).</li>
</ul>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
