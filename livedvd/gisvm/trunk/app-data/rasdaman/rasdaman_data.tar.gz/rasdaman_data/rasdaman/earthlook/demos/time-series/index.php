<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
  <script language="JavaScript" type="text/javascript">
    function openSmallWindow( url, target )
    {
      result = window.open( url, target, "width=500,height=180,resizable=yes,scrollbars=yes" );
      if (result == null)
        alert( "Error: cannot open popup window; too restrictive browser settings?" );
      return false;
    }
  </script>
</head>

<body>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>Demonstration Scenario:
<i>Sensor Timeseries</i></h1>

<p>
1-D timeseries data resemble raster (or coverage) data as well. 
Actually, <a href="../../tech/interface-wcps.php">WCPS</a> as well as the forthcoming <a href="http://www.opengeospatial.org" target="ogc">OGC</a> <a href="../../tech/interface-wcs.php">WCS</a> v1.2 standard will support timeseries coverages.
In anticipation of this we provide a demo scenario for data sets which have only a time axis.
</p>
<p>
The following Use Cases for 1-D sensor time series are being presented:
</p>
<ul>
  <li><a href="value-retrieval.php">value retrieval</a>
  <li><a href="alert.php">alerter</a>
</ul>
<p>
<b>Note:</b>
Originally we had planned to build upon measurement of physical parameters, like temperature, salinity, and water flow measured by river or ocean buoys. As it turned out rather difficult to obtain such data in sufficient amount, we finally resorted to business data.
The sample 1-D database is taken from the <a href="http://www.neural-forecasting-competition.com" target="nn3">Forecasting Competition for Neural Networks & Computational Intelligence</a> which offers empirical monthly business time series. Our extract consists of couple of such time series. As data are used for a competition, no further information about their semantics is available. Neither is it needed, however, to see the mechanisms of time series retrieval.
</p>

<?php mkNavigation("up","../index.php","value retrieval","value-retrieval.php","../index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
