<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
  <script language="JavaScript">
  // sample requests provided:
  var NIR_1 = "for c in ( NIR )\n"
            + "return\n"
            + "    encode( c[ x(0:450), y(0:300) ], \"png\" )";
  var NIR_2 = "for c in ( NIR )\n"
            + "return\n"
            + "    encode( (char) abs( c.1 - c.0 )[ x(0:450), y(0:300) ], \"png\" )";
  var NIR_3 = "for c in ( NIR )\n"
            + "return\n"
            + "    count( c.1 = 0 )";
  var NIR_4 = "for c in ( NIR )\n"
            + "return\n"
            + "    encode(\n"
            + "        (char) ( ((c.0 / ((float)c.0 + c.1))-(c.1 / ((float)c.0 + c.1)))\n"
            + "        > 0.6 ) * 255,\n"
            + "       \"png\" )";
  // paste text into query text area
  function pasteQuery( queryText )
  {
    // workaround while WCPS doesn't support newline: remove it before submitting
    //document.wcpsform.wcpsRequest.value = queryText;
    document.wcpsform.wcpsRequest.value = queryText.replace( /\n/g, " " );
    document.wcpsform.wcpsRequest.value = document.wcpsform.wcpsRequest.value.replace( / +/g, " " );
  }

  </script>
  <!-- input type=button value="graphic" onClick="passWcpsSnippet('demo1.ser');" -->
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>WCPS Sandbox</h1>

<p><i>Note:
Currently we are in the transition to WCPS 1.0.0 therefore some of the language concepts are intermittently not available. We apologize and ask for your under
standing.</i>

<p>
This area allows to try out WCPS expressions (<a href="index.php">tutorial</a>)
in its Abstract Syntax (current version: 0.0.4).
</p>
<p>
Sample coverages available are
</p>
<ul>
  <li><code>NIR</code>, a 2-D x/y false-color image with range fields <code>0</code> for near-infrared, <code>1</code> for red, and <code>2</code> for green;
  <!-- <li><code>mowglie</code>, a 3-D x/y/t RGB cube with range fields <code>red</code>, <code>green</code>, and <code>blue</code>. -->
</ul>
<table border="0" cellspacing="0" cellpadding="0">
<tr>
  <td valign="top">
    <form action="<?php echo $SERVICE_WCPS; ?>" method="post" name="wcpsform" target="result">
      <b>Type a WCPS request</b> into the editing area below:
      <br>
      <textarea class="code" id="wcpsRequest" cols="50" rows="5" name="query"></textarea>
      <br>
      When done,
      <input type="submit" value="submit WCPS request"/>
    </form>
  </td>
  <td>
    &nbsp; &nbsp; &nbsp;
  </td>
  <td valign="top" rowspan="2">
    ...or select from the <b>sample requests</b> by copying one into the editing area:<pre></pre>
    <table valign="top" align="right" border="0" cellspacing="0" cellpadding="0" style="margin-right:7px;margin-top:2px">
    <tr>
      <td valign="top">
        <input type="submit" value="copy" onClick="pasteQuery(NIR_1)"/>
      </td>
    </tr>
    </table>
    <pre class="code"><script language="JavaScript">document.write( NIR_1 );</script></pre>

<!--
    <table valign="top" align="right" border="0" cellspacing="0" cellpadding="0" style="margin-right:7px;margin-top:2px">
    <tr>
      <td valign="top">
        <input type="submit" value="copy" onClick="pasteQuery(NIR_2)"/>
      </td>
    </tr>
    </table>
    <pre class="code"><script language="JavaScript">document.write( NIR_2 );</script></pre>
-->
    <table valign="top" align="right" border="0" cellspacing="0" cellpadding="0" style="margin-right:7px;margin-top:2px">
    <tr>
      <td valign="top">
        <input type="submit" value="copy" onClick="pasteQuery(NIR_3)"/>
      </td>
    </tr>
    </table>
    <pre class="code"><script language="JavaScript">document.write( NIR_3 );</script></pre>

    <table valign="top" align="right" border="0" cellspacing="0" cellpadding="0" style="margin-right:7px;margin-top:2px">
    <tr>
      <td valign="top">
        <input type="submit" value="copy" onClick="pasteQuery(NIR_4)"/>
      </td>
    </tr>
    </table>
    <pre class="code"><script language="JavaScript">document.write( NIR_4 );</script></pre>

  </td>
</tr>
<tr>
  <td>
    <br>
    <b>WCPS response area:</b>
    <iframe src="sandbox-result-init.html" name="result" width="100%" height="265px" hspace="0" vspace="0" marginwidth="0" marginheight="0">
      Sorry, your browser doesn't support <i>iframe</i>s - cannot display results!
    </iframe>
    <br>
    <br>
  </td>
</tr>
</table>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
