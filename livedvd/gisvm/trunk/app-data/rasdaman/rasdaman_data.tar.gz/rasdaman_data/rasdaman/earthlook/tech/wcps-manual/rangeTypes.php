<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>Nesting</h1>

<p>
A range type <span class="syntax">t<sub>1</sub></span> is said to be cast-compatible with a range type <span class="syntax">t<sub>2</sub></span> iff the following conditions hold:
</p>
<ul>
  <li>Both range types, <span class="syntax">t<sub>1</sub></span> and <span class="syntax">t<sub>2</sub></span>, have the same number of field elements, say <span class="syntax">d</span>;
  <li>For each range field element position <span class="syntax">i</span> with <span class="syntax">1&le;i&le;d</span>, the ith range field type <span class="syntax">f<sub>1,i</sub></span> of <span class="syntax">t<sub>1</sub></span> is cast-compatible with the ith range field type <span class="syntax">f<sub>2,i</sub></span> of <span class="syntax">t<sub>2</sub></span>.
</ul>
<p>
A range field type <span class="syntax">f<sub>1</sub></span> is said to be cast-compatible with a range field type <span class="syntax">f<sub>2</sub></span> iff <span class="syntax">f<sub>2</sub></span> can be cast to <span class="syntax">f<sub>1</sub></span>, whereby casting of <span class="syntax">f<sub>2</sub></span> to <span class="syntax">f<sub>1</sub></span> is defined as looking up <span class="syntax">f<sub>2</sub></span> in the Table below and replacing it by its right-hand neighbour type or, if it is the last type in line, by the first type of the next line. This is repeated until either <span class="syntax">f<sub>1</sub></span> is matched, or the end of the Table below is reached. Type <span class="syntax">f<sub>1</sub></span> can be cast to type <span class="syntax">f<sub>2</sub></span> if the casting procedure terminates with finding <span class="syntax">t<sub>2</sub></span>, otherwise the cast is not possible.
</p>


<h2>Example</h2>
<p>
For three single-field coverages <span class="syntax">F</span>, <span class="syntax">I</span>, and <span class="syntax">B</span> with range types <span class="syntax">float</span>, <span class="syntax">integer</span>, and <span class="syntax">Boolean</span>, resp., the result type of the following expression is <span class="syntax">float</span>:
</p>
<pre class="code">
F + I + B
</pre>
<p>
Extending <span class="syntax">Boolean</span> to (signed or unsigned) <span class="syntax">short</span> shall map <span class="syntax">false</span> to 0 and <span class="syntax">true</span> to 1.

<center>
<p><b>Type extension rules:</b><br>
<table class="figure">
<tr><td align="center">Boolean &gt; char</td></tr>
<tr><td align="center">char &gt; Boolean</td></tr>
<tr><td align="center">Boolean &gt; unsigned char</td></tr>
<tr><td align="center">unsigned char &gt; Boolean</td></tr>
<tr><td align="center">char &gt; short</td></tr>
<tr><td align="center">char &gt; unsigned short</td></tr>
<tr><td align="center">unsigned char &gt; short</td></tr>
<tr><td align="center">unsigned char &gt; unsigned short</td></tr>
<tr><td align="center">short &gt; int</td></tr>
<tr><td align="center">short &gt; unsigned int</td></tr>
<tr><td align="center">unsigned short &gt; int</td></tr>
<tr><td align="center">unsigned short &gt; unsigned int</td></tr>
<tr><td align="center">int &gt; long</td></tr>
<tr><td align="center">int &gt; unsigned long</td></tr>
<tr><td align="center">unsigned int &gt; long</td></tr>
<tr><td align="center">unsigned int &gt; unsigned long</td></tr>
<tr><td align="center">long &gt; float</td></tr>
<tr><td align="center">float &gt; double</td></tr>
<tr><td align="center">float &gt; complex</td></tr>
<tr><td align="center">double &gt; complex2</td></tr>
<tr><td align="center">complex &gt; complex2</td></tr>
</table>
</p>
</center>

<h2>Example</h2>
<p>
For a Boolean single-field coverage B, and an integer single-field coverage I, the following expression will evaluate to some integer value:
</p>
<pre class="code">
count( I * B )
</pre>
<p>
Before executing any binary operation where the two operands are of different type a cast operation shall be attempted to achieve equal types.
If a cast is attempted or implicitly needed, but not possible according to the above rules, then an exception shall be reported. 
</p>

<p>
<span class="note">NOTE</span> 
The cast operation is the same as in programming languages and database query languages.
</p>


<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
