<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Subsetting: <br>how to cut out parts from a coverage</h1>

<p>
Frequently one does not want to download the whole coverage, but only part of it. Such a subset always is a coverage again, and actually keeps all other characteristics unchanged.
<p>
Actually there are two different variants of subsetting:
<ul>
  <li><a href=22_subsetting_domain.php>domain subsetting</a> reduces a coverage's domain, ie, its extent. A typical use case is applying a bounding box selection.
  <li><a href=25_subsetting_range.php>range subsetting</a> extracts, for each coverage cell, some of its components. A typical use case is selecting bands from satellite images.
</ul>

<p>
<b>Background information:</b>
<ul>
  <li>Notice the WCS coverage model notation: a coverage is seen as a function mapping points in some (spatial, temporal, or abstract) domain into some value set, the function's range.
</ul>

<?php mkNavigation("a first simple request","10_complete.php","domain subsetting","22_subsetting_domain.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
