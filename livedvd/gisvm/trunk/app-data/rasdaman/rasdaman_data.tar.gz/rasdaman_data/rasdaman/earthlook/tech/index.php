<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php static $homePath=".."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( $homePath ); ?>
<?php mkContentStart(); ?>

<h1>The <? earthlook(); ?> Showcase</h1>


<table align="right"><tr><td>
<img src="../images/architecture.jpg" border="0" width="450">
</td></tr></table>
<p>
This site showcases open, flexible Web access to sensor and observation data archives for navigation, extraction, aggregation, and analysis.
Generally speaking, multi-dimensional spaio-temporal raster data are served in sample use case scenarios.
</p>
<p>
Service <a href="../demos/index.php">demonstrations</a> are being implemented and populated for the following OGC interface standards:
<ul>
  <li><a href="interface-wcps.php">WCPS</a>, a WCS extension for advanced server-side processing of n-D raster data.
  <li>WCS (soon);
  <li><a href="interface-wms.php">WMS</a> for browser-friendly navigation of map data;
</ul>
<p>
The <b>service stack</b> is based on the following open-source components:
<ul>
  <li>JavaScript-based light-weight clients
  <li><a href="http://www.petascope.org" target="petascope">petascope</a> offering WCS, WCS-T, and WCPS interfaces
  <li><a href="http://www.rasdaman.org" target="rasdaman">rasdaman</a> as the core "work horse" performing raster query evaluation
  <li><a href="http://www.postgresql.org" target="pg">PostgreSQL</a> storing not only metadata, but also the raster data themselves
</ul>
<p>
Several <a href="http://www.peter-baumann.org/pubs.php" target="pb">publications</a> illustrate and detail this technology and its underlying concepts.
</p>
<p>
The overall architecture can be subdivided into a <b>portal layer</b> offering data and services over Web interfaces and a <b>data management layer</b> for the various information types. At the bottom all data meet in the same <b>database</b>, which (for the purpose of the project) makes use of the open-source <a href="http://www.postgresql.org" target="postgresql">PostgreSQL</a> database system.
</p>
<p>
Such services in future will be embedded into overall orchestrations of geo information systems where raster services are integrated with vector and meta data in a seamless way, in architectures like the one shown in the Figure.
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
