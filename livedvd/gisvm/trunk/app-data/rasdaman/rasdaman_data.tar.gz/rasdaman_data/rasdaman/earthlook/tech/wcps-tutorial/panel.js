/*
 * panel.js: display draggable result panel
 * initial position: far right, vert centered
 * must be in body section of HTML file
 */

var FloatingPanelClassName = "FloatingPanel";   // CSS name
var FloatingPanelTitle = "WCPS result area";    // currently unused
var FloatingPanelWidth = 200;                   // panel width
var FloatingPanelHeight = 200;                  // panel height
var FloatingPanelDefaultContent =
    "<table class='" + FloatingPanelClassName + "' border='0' width='100%' height='100%' valign='middle'>"
  + "  <tr><td>"
  + "    <p align='center'>WCPS response area<br>(drag to any position)</p>"
  + "  </td></tr>"
  + "</table>";
var FloatingPanelElement = null;		// the panel object itself (singleton pattern)

function FloatingPanel( container, html )
{
    this.display = display;             // show panel
    this.hide = hide;                   // hide panel
    this.setContent = setContent;       // set html displayed in the panel
    this.setWidth = setWidth;
    this.setHeight = setHeight;
    this.setTop = setTop;
    this.setRight = setRight;
    this.setLeft = setLeft;
    this.display = display;
    this.destroy = destroy;

    // position is: right aligned, ertically centered
    var pos = new Object();
    pos.x = 0;
    pos.y = (window.innerHeight - FloatingPanelHeight) / 2;

    var node = document.createElement("div");
    node.className = "FloatingPanel";
    node.style.position = 'absolute';
    node.style.top = pos.y;
    node.style.right = pos.x;   // this does _right_ alignment
    node.style.display = 'none';

    var text = document.createElement("div");
    node.appendChild(text);
    text.onmousedown = grab;
    container.appendChild(node);
    text.innerHTML = html;

    var prev_mouse_move = null;
    var prev_mouse_up = null;
    var grabbed = false;
    var grabPosition = null;

    function destroy()
    {
        container.removeChild(node);
    }

    function display()
    {
        node.style.display = 'block';
    }

    function hide()
    {
        node.style.display = 'none';
    }

    function grab(event)
    {
        if (grabbed)
            return false;
        if (event == null)
            event = window.event;
        grabbed = true;
        prev_mouse_move = document.onmousemove;
        prev_mouse_up = document.onmouseup;
        document.onmousemove = move;
        document.onmouseup = release;
        grabPosition = new Object();
        grabPosition.x = event.screenX - pos.x;
        grabPosition.y = event.screenY - pos.y;
        return false;
    }

    function move(event)
    {
        if (!grabbed)
            return false;
        if (event == null)
            event = window.event;
        pos.x = event.screenX - grabPosition.x;
        pos.y = event.screenY - grabPosition.y;
        node.style.top = pos.y;
        node.style.right = -pos.x;
        return false;
    }

    function release(event)
    {
        if (!grabbed)
            return false;
        if (event == null)
            event = window.event;
        delete grabPosition;
        grabbed = false;
        document.onmousemove = prev_mouse_move;
        document.onmouseup = prev_mouse_up;
    }

    function setContent(html)
    {
        text.innerHTML = html;
    }

    function setWidth(value)
    {
        node.style.width = value;
    }

    function setHeight(value)
    {
        node.style.height = value;
    }

    function setRight(value)
    {
        node.style.right = value;
    }

    function setLeft(value)
    {
        node.style.left = value;
    }

    function setTop(value)
    {
        node.style.top = value;
    }
}

// prevent mem leaks
if (FloatingPanelElement != null)
{
    FloatingPanelElement.destroy();
    FloatingPanelElement = null;
}

// instantiate + initialize singleton panel:
FloatingPanelElement = new FloatingPanel( document.body, FloatingPanelDefaultContent );
FloatingPanelElement.setWidth( FloatingPanelWidth );
FloatingPanelElement.setHeight( FloatingPanelHeight );
FloatingPanelElement.display();


