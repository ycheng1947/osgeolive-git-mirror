<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>trimExpr</h1>

<p>
The <span class="syntax">trimExpr</span> element extracts a subset from a given coverage expression along the axis indicated, specified by a lower and upper bound for each axis affected. Interval limits can be expressed in the coverage's image CRS or any CRS which the the coverage supports.
</p>

<p>
Lower as well as upper limits <b>must</b> lie inside the coverage's domain.
</p>

<p>
For syntactic convenience, both array-style addressing using brackets and function-style syntax are provided; both are equivalent in semantics.
</p>

<p>Let</p>

<div class="indent"><p>

<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a>, <br/>
<a name="n"></a><span class="syntax">n</span> be an <b>integer</b> with  0 &#8804; <span class="syntax">n</span> , <br/>

<a name="a1"></a><span class="syntax">a<sub>1</sub></span>, ... , <a name="an"></a><span class="syntax">a<sub>n</sub></span> be pairwise distinct <b>axisName</b>s with  <span class="syntax">a<sub>i</sub></span> &#8712; axisNameSet(<span class="syntax">C<sub>1</sub></span>) for 1 &#8804; i &#8804; <span class="syntax">n</span>, <br/>

<a name="crs1"></a><span class="syntax">a<sub>n</sub></span>, ... , <a name="crsn"></a><span class="syntax">crs<sub>n</sub></span> be pairwise distinct <b>crsName</b>s with  <span class="syntax">crs<sub>i</sub></span> &#8712; crsList(<span class="syntax">C<sub>1</sub></span>) for 1	&#8804; i &#8804; <span class="syntax">n</span>, <br/>

(<span class="syntax">lo<sub>1</sub></span>,<span class="syntax">hi<sub>1</sub></span>), ... ,(<span class="syntax">lo<sub>n</sub></span>,<span class="syntax">hi<sub>n</sub></span>) be <b>axisPoint</b> pairs with <span class="syntax">lo<sub>i</sub></span> &#8804; <span class="syntax">hi<sub>i</sub></span> for 1 &#8804; i &#8804; <span class="syntax">n</span>.

</p>
<div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C<sub>2</sub></span> <br/>
where <span class="syntax">C<sub>2</sub></span> is one of</p>
  <div class="indent"><p>
	<span class="syntax">C<sub>bracket</sub></span> 	= <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> [ <span class="syntax"><a href="#pi" class="syntax">p<sub>1</sub></a></span>, ... , <span class="syntax"><a href="#pi" class="syntax">p<sub>n</sub></a></span> ] <br/>
 	<span class="syntax">C<sub>func</sub></span> 	= <span class="code">trim ( <a href="#C1" class="syntax">C<sub>1</sub></a>, { <a href="#pi" class="syntax">p<sub>1</sub></a>, ... , <a href="#pi" class="syntax">p<sub>n</sub></a> } ) </span>
  </p></div>
<p>  
with
</p>
  <div class="indent"><p>
	<a name="pi"></a><span class="syntax">pi</span> is one of <br/>
 	<span class="syntax">p<sub>img,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">lo<sub>i</sub></span>,<span class="syntax">hi<sub>i</sub></span>) <br/>
	<span class="syntax">p<sub>crs,i</sub></span> =  <span class="syntax">a<sub>i</sub></span>(<span class="syntax">lo<sub>i</sub></span>,<span class="syntax">hi<sub>i</sub></span>)<span class="syntax">crs<sub>i</sub></span>
  </p></div>
<p>
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="trimExpr.jpg">
</p>
</div>

<p>
<span class="note">NOTE</span> It is possible to mix different CRSs in one trim operation, however each axis must be addressed in exactly one CRS (either image CRS or another supported CRS).
</p>

<p>
<span class="note">NOTE</span> A trim operation might simultaneously perform x/y trimming expressed in some geographic coordinate CRS, time trimming in a time CRS, and abstract axis trimming in (integer) grid cell coordinates.
</p>



<h2>Example</h2>
<p>
The following are syntactically valid, equivalent trim expressions:
<pre class="code">
C[ x(-180,+180), y(-90,90) ]
trim( C, { x(-180,+180), y(-90,90) } )
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
