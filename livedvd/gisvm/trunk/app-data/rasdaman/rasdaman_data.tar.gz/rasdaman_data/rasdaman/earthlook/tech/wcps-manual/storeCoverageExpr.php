<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>storeCoverageExpr</h1>

<p>
The <span class="syntax">storeCoverageExpr</span> element specifies that an encoded coverage result as described by its E sub element is not to be delivered immediately as response to the request, but to be stored on server side for subsequent retrieval. The result of the <b>coverageList</b> expression is the URL under which the result is provided by the server, and the server returns only the XML response part with the URL(s) being in place of the coverage(s) generated.
</p>


<p>Let</p>
<div class="indent"><p>
   <a name="E"></a><span class="syntax">E</span> be an <a href="encodedCoverageExpr.php" class="syntax">encodedCoverageExpr</a>. 
</p></div>
<p>Then</p>
<div class="indent"><p>
for any <a href="#URI" class="syntax">URI</a> U <br/>
where
</p>
  <div class="indent"><p>
  U =  <span class="code">store ( <a href="#E" class="syntax">E</a> ) </span>
  </p></div>
<p>
  U is defined as that URI at which the coverage result is made available by the server.
</p></div>

<h2>Example</h2>

<p>
The following expression will deliver the URL under which the server stores the TIFF-encoded result coverage C:
</p>

<pre class="code">
store( encode( C, "TIFF" ) )
</pre>


<p>
<span class="note">NOTE</span>   It is not specified in this standard for how long server-side stored coverages remain available; usually they will be deleted after some implementation dependent time to free server space. Future versions of this standard may offer means to address this.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
