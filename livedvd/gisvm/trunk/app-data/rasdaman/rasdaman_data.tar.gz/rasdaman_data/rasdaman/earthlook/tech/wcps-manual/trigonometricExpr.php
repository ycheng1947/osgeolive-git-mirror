<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>trigonometricExpr</h1>

<p>
The <span class="syntax">trigonometricExpr</span> element specifies a unary induced trigonometric operation.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span> be a <a href="coverageExpr.php" class="syntax">coverageExpr</a> <br/>
where 
</p>
  <div class="indent"><p>
  for all fields <a name="r"></a><span class="syntax">r</span> &#8712; rangeFieldNames(<a name="C1"></a><span class="syntax">C<sub>1</sub></span>): <a name="r"></a><span class="syntax">r</span> is numeric.
  </p></div>
</div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <a name="C2"></a><span class="syntax">C<sub>2</sub></span> <br/>
where <a name="C2"></a><span class="syntax">C<sub>2</sub></span> is one of 
</p>
  <div class="indent"><p>
 	C<sub>sin</sub>	=  <span class="code">sin( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>cos</sub>	=  <span class="code">cos( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>tan</sub>	=  <span class="code">tan( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>sinh</sub>	=  <span class="code">sinh( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>cosh</sub>	=  <span class="code">cosh( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>arcsin</sub>	=  <span class="code">arcsin( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>arccos</sub>	=  <span class="code">arccos( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span> <br/>
	C<sub>arctan</sub>	=  <span class="code">arctan( <a href="#C1" class="syntax">C<sub>1</sub></a> ) </span>

  </p></div>
<p>  
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="trigonometricExpr.jpg">
</p>
</div>


<p>The server <b>shall</b> respond with an exception if one of the coverage's grid cell values or its null values is not within the domain of the function to be applied to it.
</p>

<h2>Example</h2>
<p>
The following expression replaces all (numeric) values of coverage C with their sine:
<pre class="code">
sin ( C )
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
