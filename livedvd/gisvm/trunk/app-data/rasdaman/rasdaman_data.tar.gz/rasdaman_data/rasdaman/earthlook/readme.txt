first draft : Keshab Neupane

newearthlook directory structure

demos contains all other sub-directories
each subdirectory contains all the files responsible for that particular demo
ccip directory is further sub-divided, to include demos related to it
directory extras is to store anything extra relavant to demos but not directly related to demo
index.php is the main php file, which contains navigation to other pages

directory oldcopy is temporary directory that stores old materials, from where things are to copied and 
put into respective new sub-directory relavant for the demo

second draft: Shaan Rauniyar

Index.php working fine except
missing resources: /newearthlook/demos/ocean/%3C

Missing Links in Web Map Service
