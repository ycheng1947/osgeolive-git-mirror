<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>subsetExpr</h1>

<p>
The <span class="syntax">subsetExpr</span> element specifies spatial and temporal domain subsetting. It encompasses spatial and temporal trimming (i.e. constraining the result coverage domain to a subinterval, slicing (i.e. cutting out a hyperplane from a coverage) extending and scaling  of a coverage expression.
</p>

<p>
All of the <span class="syntax">subsetExpr</span> elements allow to make use of coordinate reference systems other than a coverage's image CRS. A coverage's individual mapping from general domain to image CRS (grid cell) coordinates does not need to be disclosed by the server, hence any coordinate transformation should be considered a "black box" by the client.
</p>

<p>
<span class="note">NOTE</span> The special case that subsetting leads to a single cell remaining still resembles a coverage by definition; this coverage is viewed as being of dimension 0.
</p>

<p>
<span class="note">NOTE</span> Range subsetting is accomplished via the unary induced <a href="fieldExpr.php" class="syntax">fieldExpr</a>.
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
