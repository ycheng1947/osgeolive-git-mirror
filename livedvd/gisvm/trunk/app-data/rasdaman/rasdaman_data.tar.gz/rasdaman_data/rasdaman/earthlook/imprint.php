<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>Imprint</h1>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td width="45%" valign="top">
    <fieldset class="imprint">
      <legend>This website is produced and maintained by:</legend>
      <nobr>
        <b><a href="http://www.jacobs-university.de">Jacobs University Bremen</a></b>
      </nobr>
      <table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td> Campus Ring 1 </td>
      </tr>
      <tr>
        <td> D-28757 Bremen </td>
      </tr>
      <tr>
        <td> Germany </td>
      </tr>
      </table>
    </fieldset>
  </td>
  <td width="10%"> &nbsp; </td>
  <td width="45%" valign="top">
    <fieldset class="imprint">
      <legend>point of contact:</legend>
      <b><a href="http://www.faculty.jacobs-university.de/pbaumann">Peter Baumann</a></b>
      <table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td> tel </td>
        <td> +49-421-200-3178 </td>
      </tr>
      <tr>
        <td> fax </td>
        <td> +49-421-200-493178 </td>
      </tr>
      <tr>
        <td> email </td>
        <td> <?php mkEmail( 'p.baumann', 'jacobs-university', 'de' ); ?> </td>
      </tr>
      </table>
    </fieldset>
  </td>
</tr>
</table>

<a name="ipr"></a>
<h2>Intellectual Property Rights</h2>

<p>
Data have been provided courtesy of the collaborating and other organisations.
We gratefully acknowledge this in a time where many institutions tend to not disclose their data publicly.
</p>
<p>
It is not allowed to copy or use the data sets in any way without giving proper credit to both the data provider and <?php rasdaman(); ?>.
</p>

<h2>Disclaimer</h2>

<p>
All external links implemented on this site have been checked for conformance with the spirit and intent of this site, and have found conformant at this time.
However, the maintainer of this site has no control over the (change of) contents of the referred websites and, therefore, does not assume any responsibility for the contents of referred websites.
</p>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
