<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../../.."; ?>
  <?php include_once( $homePath . '/globals_ccip.inc' ); ?>
  <?php printHead(); ?>
  <link type="text/css" rel="stylesheet" href="<?php echo $homePath ?>/WebView.css">
  <script type="text/javascript" language="javascript" src="<?php echo $homePath ?>/webview/webview.nocache.js"></script>

  <script language="JavaScript" type="text/javascript">
    var REQUEST_TS_1 = '<pre class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode( t1, "csv" )</pre>';
    var REQUEST_TS_2 = '<pre class="code">for t2 in ( ts_002 )\n'
                     + 'return\n'
                     + '    encode( t2, "csv" )</pre>';
    var REQUEST_TS_3 = '<pre class="code">for t3 in ( ts_003 )\n'
                     + 'return\n'
                     + '    encode( t3, "csv" )</pre>';
    var REQUEST_TS_4 = '<pre class="code">for t4 in ( ts_004 )\n'
                     + 'return\n'
                     + '    encode( t4, "csv" )</pre>';

    var REQUEST_EXTRACT_1 = '<pre class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode( t1[ t(0:49) ], "csv" )</pre>';
    var REQUEST_EXTRACT_2 = '<pre class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode( t1[ t(15:50) ], "csv" )</pre>';

    var REQUEST_SCALE = '<pre class="code">for t1 in ( ts_001 )\n'
                     + 'return\n'
                     + '    encode(\n'
                     + '        coverage downscaled_t1\n'
                     + '        using    t(0:24)\n'
                     + '        values   t1[ t*5 ],\n'
                     + '        "csv" )</pre>';

    var REQUEST_THR_1 = '<pre class="code">for t1 in ( ts_001 ),\n'
                     + '    t2 in ( ts_002 ),\n'
                     + '    t3 in ( ts_003 )\n'
                     + 'return\n'
                     + '    encode( t1 + t2 + t3 > 20000, "csv" )</pre>';
    var REQUEST_THR_2 = '<pre class="code">for t1 in ( ts_001 ),\n'
                     + '    t2 in ( ts_002 ),\n'
                     + '    t3 in ( ts_003 )\n'
                     + 'return\n'
                     + '    encode( t1 + t2 + t3 > 22000, "csv" )</pre>';

    function openSmallWindow( url, target )
    {
      result = window.open( url, target, "width=500,height=180,resizable=yes,scrollbars=yes" );
      if (result == null)
        alert( "Error: cannot open popup window; too restrictive browser settings?" );
      return false;
    }
  </script>
</head>

<body>
<script type="text/javascript" src="wz_tooltip.js"></script>
<div id="meta" queries="query1 query2 query3 query4 query5 query6 query7 query8 query9" submitters="q1 q2 q3 q4 q5 q6 q7 q8 q9">      </div>

<?php mkContentStart(); ?>

    <div id="query1" template="for t1 in ( NN3_1 ) return encode( t1, &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query2" template="for t1 in ( NN3_2 ) return encode( t1, &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query3" template="for t1 in ( NN3_3 ) return encode( t1, &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query4" template="for t1 in ( NN3_4 ) return encode( t1, &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query5" template="for t1 in ( NN3_1 ) return encode( t1[ t(0:51) ], &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query6" template="for t1 in ( NN3_1 ) return encode( t1[ t(15:52) ], &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query7" template="for t1 in ( NN3_1 ) return encode( t1[ t(15:52) ], &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query8" template="for t1 in ( NN3_1 ), t2 in ( NN3_2), t3 in (NN3_3) return encode( t1 + t2 + t3 > 20000, &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>
    <div id="query9" template="for t1 in ( NN3_1 ), t2 in ( NN3_2), t3 in (NN3_3) return encode( t1 + t2 + t3 > 22000, &quot;csv&quot;)" columns="1" lines="1" resultType="chart" resultObject="img0" style="display:none"></div>



<table border="0" cellspacing="15">
<tr>
  <td colspan="2"><li>original timeseries:</td>
  <td rowspan="10"><div id="img0" width="400px" height="70px" title="" xAxisLabel="time" yAxisLabel=""  xAxisTickCount="4" > </div></td>
</tr>
<tr>
  <td valign="top">
    <div id="q1" text="ts_001" queries="query1" type="link" onMouseOver="Tip(REQUEST_TS_1)"> </div>
    <div id="q2" text="ts_002" queries="query2" type="link" onMouseOver="Tip(REQUEST_TS_2)"> </div>
    <div id="q3" text="ts_003" queries="query3" type="link" onMouseOver="Tip(REQUEST_TS_3)"> </div>
    <div id="q4" text="ts_004" queries="query4" type="link" onMouseOver="Tip(REQUEST_TS_4)"> </div>
  </td>
  <td></td>
</tr>
<tr>
  <td colspan="2"><li>From timeseries <code>ts_001</code>, ...</td>
  <td></td>
</tr>
<tr>
  <td valign="top">
    <div id="q5" text="...the first 50 values" queries="query5" type="link" onMouseOver="Tip(REQUEST_EXTRACT_1)"> </div>
    <div id="q6" text="...values 15 through 50" queries="query6" type="link" onMouseOver="Tip(REQUEST_EXTRACT_2)"> </div>
  </td>
  <td></td>
</tr>
<tr>
  <td colspan="2"><li>From timeseries <code>ts_001</code>, ...</td>
  <td></td>
</tr>
<tr>
  <td valign="top">
     <div id="q7" text="...every 5th value" queries="query7" type="link" onMouseOver="Tip(REQUEST_SCALE)"> </div>
     (this resembles 'nearest neighbour' interpolation)
  </td>
  <td></td>
</tr>
<tr>
  <td colspan="2"><li>At what points in time does the sum of timeseries <code>ts_001</code>, <code>ts_002</code>, and <code>ts_003</code> values exceed...</td>
  <td></td>
</tr>
<tr>
  <td>
     <div id="q8" text="...threshold 20000?" queries="query8" type="link" onMouseOver="Tip(REQUEST_THR_1)"> </div>
     <div id="q9" text="...threshold 22000?" queries="query9" type="link" onMouseOver="Tip(REQUEST_THR_2)"> </div>
  </td>
  <td></td>
</tr>
</table>

<?php mkContentEnd(); ?>

</body>
</html>
