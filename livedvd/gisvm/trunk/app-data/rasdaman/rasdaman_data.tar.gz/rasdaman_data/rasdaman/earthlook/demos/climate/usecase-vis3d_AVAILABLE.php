<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php static $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>

  <script language="JavaScript" type="text/javascript">
    function openSmallWindow( url, target, width, height )
    {
      result = window.open( url, target, "width=" + width + ",height=" + height + ",resizable=yes,scrollbars=yes" );
      if (result == null)
        alert( "Error: cannot open popup window; too restrictive browser settings?" );
      return false;
    }
  </script>
</head>

<body>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>Climate Modeling and Prediction: <i>3-D Ortho Slicing</i></h1>

<p>
<b>Use Case:</b>
Climate researchers want to browse a 3-D or 4-D data set by inspecting 3-D (sub)cubes. For 3-D data sets, they select the entire set (possibly downscaled); for 4-D data sets, they select some 3-D subset by indicating a slicing position on the x, y, z, or time axis. The resulting 3-D cube is displayed spatially, represented as three orthogonal slices; controls allow to zoom, pan, turn, and move the slices.
</p>
<p>
<b>The Service:</b>
The following Use Cases for 2-D imagery and 3-D image time series are being presented:
</p>

<table border="0">
<tr>
  <td rowspan="2" valign="top">
    <iframe src="climate-init-vis3d.html" name="climateOrthoSlicing" width="400" height="300" align="center" frameborder="no" marginwidth="0" marginheight="0" vspace="0" hspace="0" scrolling="no">
    Your browser does not support iframes, hence the service unfortunately cannot be displayed.
    </iframe>
  </td>
  <td valign="top">
    <b>Pick a data set</b> from the (4-D = x/y/z/t) atmospheric temperature simulation result for display in the interaction area (left):
    <ul>
      <li><a href="<?php echo $SERVICE_VIS3D; ?>/climate-tp-bottom.html"   target="climateOrthoSlicing">over ground</a> or
          <a href="<?php echo $SERVICE_VIS3D; ?>/climate-tp-top.html"      target="climateOrthoSlicing">stratosphere</a> (x/y/t)
      <li><a href="<?php echo $SERVICE_VIS3D; ?>/climate-tp-latest.html"   target="climateOrthoSlicing">latest snapshot</a> (x/y/z)
      <li><a href="<?php echo $SERVICE_VIS3D; ?>/climate-tp-meridian.html" target="climateOrthoSlicing">along meridian</a> (y/t/z)
    </ul>
  </td>
</tr>
<tr>
  <td valign="bottom">
    <h2>Viewer Instructions</h2>
    <p>
    The
    <a href="system-requirements.html" target="sysreq" onclick="openSmallWindow('system-requirements.html','sysreq',520,200)">system requirements</a>
    and
    <a href="user-guide.html" target="guide" onclick="openSmallWindow('user-guide.html','guide',540,230)">user guide</a> (open in new windows).
    </p>
    <p>
    Upon loading this page the JOGL (Java OpenGL) runtime system, signed by <a href="http://www.sun.com" target="sun">Sun Microsystems</a>, as well as the vis3D applet need permission to execute on your computer.
    </p>
    <p>
    Please allow Java a few seconds for loading on your PC.
    </p>
  </td>
</tr>
</table>

<?php mkNavigation("slicing","usecase-slicing.php","demo overview","../index.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
