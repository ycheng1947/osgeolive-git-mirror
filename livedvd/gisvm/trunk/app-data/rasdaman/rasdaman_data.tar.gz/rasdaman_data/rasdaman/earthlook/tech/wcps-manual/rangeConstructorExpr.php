<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>rangeConstructorExpr</h1>

<p>
The <span class="syntax">rangeConstructorExpr</span>, an n-ary induced operation, allows to build coverages with compound range structures. To this end, coverage range field expressions enumerated are combined into one coverage. All input coverages must match wrt. domains and CRSs.
</p>

<p>
It is allowed to list an input coverage more than once.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="n"></a><span class="syntax">n</span> be an <b>integer</b> with n &#8805; 1, <br/>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span>, ... , <a name="Cn"></a><span class="syntax">C<sub>n</sub></span> be <a href="coverageExpr.php" class="syntax">coverageExpr</a>s, <br/>
<a name="f1"></a><span class="syntax">f<sub>1</sub></span>, ... , <a name="fn"></a><span class="syntax">f<sub>n</sub></span> be <b>fieldName</b>s <br/>
where 
</p>
  <div class="indent"><p>
 	<span class="syntax">fi</span> &#8712; rangeFieldNames(<span class="syntax">C<sub>i</sub></span>), <br/>
 	imageCrs(<span class="syntax">C<sub>i</sub></span>) = imageCrs(<span class="syntax">C<sub>j</sub></span>), <br/>
 	imageCrsDomain(<span class="syntax">C<sub>i</sub></span>) = imageCrsDomain(<span class="syntax">C<sub>j</sub></span>), <br/>
 	crsSet(<span class="syntax">C<sub>i</sub></span>) = crsSet(<span class="syntax">C<sub>j</sub></span>), <br/>
 	generalDomain(<span class="syntax">C<sub>i</sub></span>,<span class="syntax">a<sub>i</sub></span>,<span class="syntax">C<sub>i</sub></span>) = generalDomain(<span class="syntax">C<sub>j</sub></span>,<span class="syntax">a<sub>j</sub></span>,<span class="syntax">C<sub>j</sub></span>) <br/>
 		for all <span class="syntax">a<sub>i</sub></span> &#8712; axisSet(<span class="syntax">C<sub>i</sub></span>), <span class="syntax">a<sub>j</sub></span> &#8712; axisSet(<span class="syntax">C<sub>j</sub></span>), <span class="syntax">C<sub>i</sub></span> &#8712; crsSet(<span class="syntax">C<sub>i</sub></span>), <span class="syntax">C<sub>j</sub></span> &#8712; crsSet(<span class="syntax">C<sub>j</sub></span>).
 	</p></div>	
</div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C'</span> <br/>
where </p>
  <pre class="code">
  C' =  { <a href="#C1" class="syntax">C<sub>1</sub></a> , ... , <a href="#Cn" class="syntax">C<sub>n</sub></a> }
  </pre>
<p>  
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="rangeConstructorExpr.jpg">
</p>
</div>

<h2>Example</h2>
<p>
The expression below does a false color encoding by combining near-infrared, red, and green bands into a 3-band image of 8-bit channels each, which can be visually interpreted as RGB:
<pre class="code">
{ (char) L.nir, (char) L.red, (char) L.green }
</pre>
</p>

<p>
The following expression transforms a greyscale image G containing a single range field panchromatic into an RGB-structured image:
</p>
<pre class="code">
{ G.panchromatic, G.panchromatic, G.panchromatic }
</pre>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
