<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>scalarExpr</h1>
<p>
The <span class="syntax">scalarExpr</span> element is either a <a href="getMetaDataExpr.php" class="syntax">getMetaDataExpr</a> or a <a href="condenseExpr.php" class="syntax">condenseExpr</a>. 
</p>

<p><span class="note">NOTE</span>	As such, it returns a result which is not a coverage.</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
