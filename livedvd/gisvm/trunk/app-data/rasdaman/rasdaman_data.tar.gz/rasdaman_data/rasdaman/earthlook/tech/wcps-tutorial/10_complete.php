<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "." ); ?>
<?php mkContentStart(); ?>

<h1>A First Simple Request</h1>

<p>
A WCPS <code>ProcessCoverage</code> request uniformly consists of one expression which is evaluated against one or more coverages and returns a coverage, coverage set, or derived alphanumeric data.

<p>
<b>Example:</b>
Coverage <code>rgb</code> is a 2-D RGB image of size 400x344 pixels.
The request below retrieves the entire image, without any change in CRS, size, or cell value ("radiometry").
<p>

<pre class="code">for c in ( rgb )
return
        encode( c, "jpeg" )
</pre>

<p>
The result of this request is displayed below:
<div class="response">
  <img align="center" src="images/10_rgb.jpg">
</div>
<p>
WCPS is not constrained to simply accessing coverages. The first argument of the <code>encode()</code> function can be an arbitrarily complex expression based on the WCPS coverage language elements.
<p>
<b>Example:</b> "an intensity-inverted cutout in the blue channel":
<pre class="code">for c in ( rgb )
return
        encode( <span class="hilite">(255c - c.red)[50:150,50:150]</span>, "jpeg" )
</pre>
<p>
This is the outcome of the above request:
<div class="response">
  <img align="center" src="images/10_rgb-processed.jpg">
</div>

<p>
The <code>encode()</code> function is always required when the overall result of a <code>return</code> clause is a coverage. Obviously the format chosen must support the coverage wrt. number of dimensions (JPEG cannot handle 3D) and cell type (JPEG also cannot handle floating-point pixels). If the overall result of the request is just a scalar, then no encoding is needed.
<p>
<b>Example:</b> "the number of pixels with zero-valued red components":
<pre class="code">for c in ( rgb )
return
        <span class="hilite">count( c.red = 0 )</span>
</pre>
<p>
Next, the most important language constructs will be introduced step by step.
<p>
<b>Background information:</b>
<ul>
  <li>The format names available are depending on the server implementation.
  <li>Some formats support further parameter (such as JPEG quality indicators); the <code>encode()</code> function allows passing such extra parameters as an optional string. The syntax and semantics of this string is currently not fixed in the standard, but may be so in future.
</ul>

<p>
<b>See manual:</b>
<a href="../wcps-manual/coverageListExpr.php">coverageListExpr</a>

<?php mkNavigation("Table of Contents","index.php","Domain Subsetting","20_subsetting.php","index.php"); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
