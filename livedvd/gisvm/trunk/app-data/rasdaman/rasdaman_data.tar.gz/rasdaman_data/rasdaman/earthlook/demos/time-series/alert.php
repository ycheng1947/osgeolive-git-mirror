<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php $homePath="../.."; ?>
<?php include_once( $homePath . '/globals.inc' ); ?>

<style>
span.on  { background-color: #ff3333; }
span.off { background-color: #33ff33; }
</style>

<script language="JavaScript" type="text/javascript">
var THRESHOLD = 8080;

var http = false;
var maxTime = 126;
var currentTime = 0;

if(navigator.appName == "Microsoft Internet Explorer")
{
	http = new ActiveXObject("Microsoft.XMLHTTP");
}
else
{
	http = new XMLHttpRequest();
} 

function replaceVal()
{
	url = "valBox.php?time=" + currentTime;
	http.open("POST", url, true);
	currentTime = (currentTime + 1) % maxTime;
	http.onreadystatechange=function()
	{
		if(http.readyState == 4)
		{
			val = http.responseText;
			val = val.replace( /<.*>/g, "" );
			if (parseFloat(val) < THRESHOLD)
			{
				document.getElementById( 'valueBox' ).innerHTML = "<span class='off'>" + val + "<span>";
			}
			else
			{
				document.getElementById( 'valueBox' ).innerHTML = "<span class='on'>" + val + "<span>";
			}
		}
	}
	http.send(null);
	setTimeout(replaceVal, 1000);
}
function replaceAvg()
{
	url = "avgBox.php?time=" + currentTime;
	http.open("POST", url, true);
	currentTime = (currentTime + 1) % maxTime;
	http.onreadystatechange=function()
	{
		if(http.readyState == 4)
		{
			val = http.responseText;
			val = val.replace( /<.*>/g, "" );
			if (val < THRESHOLD)
			{
				document.getElementById( 'avgBox' ).innerHTML = "<span class='off'>" + val + "<span>";
			}
			else
			{
				document.getElementById( 'avgBox' ).innerHTML = "<span class='on'>" + val + "<span>";
			}
		}
	}
	http.send(null);
	setTimeout(replaceAvg, 1000);
}
</script>
</head>

<body>

<?php mkHeader(); ?>
<?php mkContentStart(); ?>

<h1>Sensor Timeseries: <i>Alerting</i></h1>

<p>
<b>Use Case:</b>
For some sensor data, which are updated in the database at unknown times, a continuous monitoring wrt. some given condition is required. This condition can be given by the last value inserted into the sensor coverage (eg, for thresholding critical water levels), or some aggregation (like the sum over all values measured so far for water flow), or even involve a combination of serveral coverages (like precipitation, water flow, and population density).
</p>
<p>
<b>The service:</b>
In the following text, a green background indicates that the value observed is below threshold value <tt><script language="javascript">document.write(THRESHOLD);</script></tt>, while a red background indicates a threshold exceeded.
</p>
<ul>
<li>current value is
<span id="valueBox">[<a href="javascript:replaceVal()"><b>start alert</b></a>]</span>;
<li>average over all values up to now currently is
<span id="avgBox"  >[<a href="javascript:replaceAvg()"><b>start alert</b></a>]</span>.
</em>
</ul>
<p>
<form action="<?php echo $SERVICE_WCPS; ?>" method="post">
<input type=hidden name="query" value="for t in ( NN3_1 ) return max( t )">
<input type="hidden" value="attempt"/>
</form>
</p>

<p>
<b>Implementation:</b> the "NOW" timepoint iterates over the stored coverage, periodically executing the WCPS requests displayed when the mouse is over the start link. The WCPS requests used are:
</p>

<table border="0" align="center">
<tr>
<td>
<pre class="code">for t in ( NN3_1 )
return
<span class="hilite">t[ t(NOW) ]</span></pre>
</td>
<td>
<pre class="code">for t in ( NN3_1 )
return
<span class="hilite">avg( t[ t(0:NOW) ]</span></pre>
</td>
</tr>
</table>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
