<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>binaryInducedExpr</h1>

<p>
The <span class="syntax">binaryInducedExpr</span> element specifies a binary induced operation, i.e., an operation involving two coverage-valued arguments.
</p>

<p>
The coverage range types <b>shall</b> be numeric.
</p>

<p>Let</p>

<div class="indent"><p>
<a name="C1"></a><span class="syntax">C<sub>1</sub></span>, <a name="C2"></a><span class="syntax">C<sub>2</sub></span> be <a href="coverageExpr.php" class="syntax">coverageExpr</a>s, <br/>
<a name="S1"></a><span class="syntax">S<sub>1</sub></span>, <a name="S2"></a><span class="syntax">S<sub>2</sub></span> be <a href="rangeValue.php" class="syntax">rangeValue</a>s, <br/>
where
  <div class="indent"><p>
  	imageCrsDomain(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>,<span class="syntax">a</span>) = imageCrsDomain(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>,<span class="syntax">a</span>), <br/>
    imageCrs(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>,<span class="syntax">a</span>) = imageCrs(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>,<span class="syntax">a</span>), <br/>
    generalDomain(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>,<span class="syntax">a</span>) = generalDomain(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>,<span class="syntax">a</span>), <br/>
    crsSet(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>,<span class="syntax">a</span>) = crsSet(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>,<span class="syntax">a</span>) for all <span class="syntax">a</span> &#8712; axisSet(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>), <br/>
    crsSet(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>) = crs(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>), <br/>
    rangeFieldNames(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>) = rangeFieldNames(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>), <br/>
    rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>,<span class="syntax">f</span>) is cast-compatible with rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>,<span class="syntax">f</span>) or 
      rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>,<span class="syntax">f</span>) is cast-compatible with rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>,<span class="syntax">f</span>)
      for all <span class="syntax">f</span> &#8712; rangeFieldNames(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>),	<br/>
    null(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>) = null(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>), <br/>
    <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> are of type rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>).
  </p></div>
</div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <a name="C3"></a><span class="syntax">C<sub>3</sub></span> <br/>
where <span class="syntax">C<sub>3</sub></span> is one of
</p>
  <div class="indent"><p>
 	C<sub>plusCC</sub> =  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>+</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>minCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>-</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>multCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>*</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>divCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>/</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>andCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>and</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <br/>
 			rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>)=rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>)=Boolean<br/>
 	C<sub>orCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>or</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and<br/>
 			rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>)=rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>)=Boolean<br/>
 	C<sub>xorCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>xor</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and<br/>
 			rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>)=rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>)=Boolean<br/>
 	C<sub>eqCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>ltCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b><</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>gtCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>></b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>leCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b><=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>geCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>>=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>neCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>!=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>ovlCC</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>overlay</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
	C<sub>plusSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>+</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>minSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>-</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>multSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>*</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>divSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>/</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric<br/>
 	C<sub>andSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>and</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) Boolean<br/>
 	C<sub>orSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>or</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) Boolean<br/>
 	C<sub>xorSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>xor</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) Boolean<br/>
 	C<sub>eqSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>ltSC</sub>		=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b><</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>gtSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>></b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>leSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b><=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>geSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>>=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>neSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>!=</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
 	C<sub>ovlSC</sub>	=  <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span> <b>overlay</b> <span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>	and <span class="syntax"><a href="#S1" class="syntax">S<sub>1</sub></a></span>, rangeType(<span class="syntax"><a href="#C2" class="syntax">C<sub>2</sub></a></span>) numeric or Boolean<br/>
	C<sub>plusCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>+</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric<br/>
 	C<sub>minCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>-</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric<br/>
 	C<sub>multCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>*</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric<br/>
 	C<sub>divCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>/</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric<br/>
 	C<sub>andCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>and</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> Boolean<br/>
 	C<sub>orCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>or</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> Boolean<br/>
 	C<sub>xorCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>xor</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> Boolean<br/>
 	C<sub>eqCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>=</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric or Boolean<br/>
 	C<sub>ltCS</sub> 	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b><</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric or Boolean<br/>
 	C<sub>gtCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>></b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric or Boolean<br/>
 	C<sub>leCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b><=</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric or Boolean<br/>
 	C<sub>geCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>>=</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric or Boolean<br/>
 	C<sub>neCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>!=</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric or Boolean<br/>
 	C<sub>ovlCS</sub>	=  <span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span> <b>overlay</b> <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span>	and rangeType(<span class="syntax"><a href="#C1" class="syntax">C<sub>1</sub></a></span>), <span class="syntax"><a href="#S2" class="syntax">S<sub>2</sub></a></span> numeric or Boolean
  </p></div>
<p>  
<a name="C2"></a><span class="syntax">C<sub>2</sub></span> is defined as follows: <br/> <br/>
<img src="binaryInducedExpr.jpg">
</p>
</div>


<h2>Example</h2>
<p>
The following expression describes a coverage composed of the sum of the red, green, and blue fields of coverage C: 
<pre class="code">
C.red + C.green + C.blue
</pre>
</p>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
