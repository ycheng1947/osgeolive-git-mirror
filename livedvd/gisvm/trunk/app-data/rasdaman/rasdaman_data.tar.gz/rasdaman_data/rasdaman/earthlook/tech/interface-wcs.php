<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php static $homePath=".."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( $homePath ); ?>
<?php mkContentStart(); ?>

<h1>Interfaces: WCS</h1>

<p>
<em>-- due to a current rework of the WCS standard this section will become available later.
For the moment being you may want to look at <a href="interface-wcps.php">WCPS</a> which is a superset of WCS expressive power.</em>
</p>
<p>
The <a href="http://www.opengeospatial.org">OGC</a> <i>Web Coverage Service (WCS) <a href="specdoc/06-083r8_OpenGIS_Web_Coverage_Service_WCS_Implementation_Specification_v_1.1.pdf">Implementation Specification</a></i> supports electronic retrieval of geospatial data as "coverages" - that is, digital geospatial information representing space-varying phenomena.
A WCS provides access to potentially detailed and rich sets of geospatial information, in forms that are useful for client-side rendering, multi-valued coverages, and input into scientific models and other clients.
[<a href="specdoc/06-083r8_OpenGIS_Web_Coverage_Service_WCS_Implementation_Specification_v_1.1.pdf">WCS 1.1</a>]
</p>

<p>
WCS and <a href="interface-wms.php">WMS</a> differ in that WMS aims at portrayal, i.e., delivering images of which the original information usually cannot be extracted by a machine, whereas WCS also allows to retrieve coverage data preserving the original semantics. <a href="interface-wcps.php">WCPS</a> adds versatile server-side processing capabilities to WCS.
<p>

<!-- <?php earthlook(); ?> offers WCS demonstrations for the following <a href="../demos.php">application scenarios</a>:
<ul>
  <li><a href="../demo/ocean/index.php">oceanography</a> (2D)
  <li><a href="../demo/remotesensing/index.php">remote sensing</a> (2D, 3D)
  <li><a href="../demo/geophysics/index.php">geophysics</a> (3D)
  <li><a href="../demo/climate/index.php">climate modeling &amp; prediction</a> (4D)
</ul>
</p>
-->

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>

</body>
</html>
