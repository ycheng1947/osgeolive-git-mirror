<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>coverageConstructorExpr</h1>

<p>
The <span class="syntax">coverageConstructorExpr</span> element allows to create a <span class="syntax">d</span>-dimensional coverage for some <span class="syntax">d</span> &#8805; 1. 
</p>

<p>
The domain definition consists, for each dimension, of a unique axis name plus lower and upper bound of the coverage, expressed in a fixed image CRS and using integer coordinates; for this image CRS one of the identifiers listed in [05-096r1] Table 1 <b>shall</b> be used. 
</p>

<p>
The coverage's content is defined by a general expression. The result type of the expres-sion defining the contents also determines the coverage range type.
</p>

<p>
This coverage has no other CRS associated beyond the abovementioned image CRS; fur-ther, it has no null values and interpolation methods associated. Finally, all other metadata are undefined. To set specific metadata for this new coverage the <a href="setMetaDataExpr.php" class="syntax">setMetaDataExpr</a> is available.
</p>

<p>
<span class="note">NOTE</span> This constructor is useful 
<ul>
<li>whenever the coverage is too large to be described as a constant or </li>
<li>when the coverage's cell values are derived from some other source (such as a histogram computation, see example below).</li>
</ul>
</p>


<p>Let</p>

<div class="indent"><p>

<a name="f"></a><span class="syntax">f</span> be a <b>fieldName</b>, <br/>

<a name="d"></a><span class="syntax">d</span> be an <b>integer</b> with <span class="syntax">d</span> > 0, <br/>

<a name="ti"></a><span class="syntax">t<sub>i</sub></span> be a <b>axisType</b>s for 1 &#8804; i &#8804; <span class="syntax">d</span>, where only axis type abstract <b>can</b> occur more than once, <br/>

<a name="namei"></a><span class="syntax">name<sub>i</sub></span> be pairwise distinct <b>identifier</b>s for 1 &#8804; i &#8804; <span class="syntax">d</span>, which additionally, in the request on hand, are not used already as a variable in this expression's scope, <br/>

<a name="loi"></a><span class="syntax">lo<sub>i</sub></span> and <a name="hii"></a><span class="syntax">hi<sub>i</sub></span> be <b>integer</b>s for 1 &#8804; i &#8804; <span class="syntax">d</span> with <span class="syntax">lo<sub>i</sub></span> &#8804; <span class="syntax">hi<sub>i</sub></span>, <br/>

<a name="V"></a><span class="syntax">V</span> be a <a href="scalarExpr.php" class="syntax">scalarExpr</a> possibly containing occurrences of <span class="syntax">name<sub>i</sub></span>.

</p></div>

<p>Then,</p>

<div class="indent"><p>
for any <a href="coverageExpr.php" class="syntax">coverageExpr</a> <span class="syntax">C<sub>2</sub></span> <br/>
where <br/></p>
<pre class="code">
  C  =	coverage f
        over <a href="#ti" class="syntax">t<sub>1</sub></a> <a href="#namei" class="syntax">name<sub>1</sub></a> (<a href="#loi" class="syntax">lo<sub>1</sub></a>,<a href="#hii" class="syntax">hi<sub>1</sub></a>),
        ... ,
        <a href="#ti" class="syntax">t</a><sub><a href="#d" class="syntax">d</a></sub> <a href="#namei" class="syntax">name</a><sub><a href="#d" class="syntax">d</a></sub> (<a href="#loi" class="syntax">lo</a><sub><a href="#d" class="syntax">d</a></sub>,<a href="#hii" class="syntax">hi</a><sub><a href="#d" class="syntax">d</a></sub>)
        values 	<a href="#V" class="syntax">V</a></pre class="code">
<p><span class="syntax">C</span> is defined as follows: <br/> <br/>
<img src="coverageConstructorExpr.jpg">
</p>
</div>

<p>
<sup>6</sup>Note that, due to the empty crsSet, this "loop" anyway will not be "entered".
</p>


<h2>Example</h2>
<p>The expression below represents a 2-D greyscale image with a diagonal shade from white to black (the cast operator forces the floating point division result into an integer):
</p>
<pre class="code">
coverage greyshade
over     x x(0,255),
         y y(0,255)
values	 (char) (x+y)/2
</pre>

<h2>Example</h2>
<p>
The expression below computes a 256-bucket histogram over some coverage <span class="syntax">C</span> of unknown domain and dimension:
</p>
<pre class="code">
coverage histogram
over     bucket histogram(0,255)
values	 count( C = bucket )
</pre>

<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
