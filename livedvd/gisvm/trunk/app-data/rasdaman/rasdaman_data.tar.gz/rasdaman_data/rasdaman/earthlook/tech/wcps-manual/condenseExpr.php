<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <?php $homePath="../.."; ?>
  <?php include_once( $homePath . '/globals.inc' ); ?>
</head>

<body>

<?php mkHeader( "" ); ?>
<?php mkContentStart(); ?>

<?php mkManualNavigation(); ?>

<h1>condenseExpr</h1>

<p>
A <span class="syntax">condenseExpr</span> is either a <a href="reduceExpr.php" class="syntax">reduceExpr</a> or a <a href="generalCondenseExpr.php" class="syntax">generalCondenseExpr</a>. It takes a coverage and summarizes its values using some summarization function. The value returned is scalar.
</p>


<?php mkManualNavigation(); ?>

<?php mkContentEnd(); ?>
<?php mkFooter(); ?>


</body>
</html>
